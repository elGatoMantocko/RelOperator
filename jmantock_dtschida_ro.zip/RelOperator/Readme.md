# Minibase Relational Operators

This project implements the three critical database relational operators: select, project, and join.

To run classes ROTest and QEPTest, run the make command.

SampleData directory path is src/SampleData

If you wish to change the sample data directory, you will have to change the java call in the makefile.

Maven is required to run Junit test cases. With maven version 3.3.9 installed, run mvn test.
